AMEZA STORE - Shopify install (Online Store 2.0 / Dawn)
1. Themes > Duplicate your theme (backup) > Edit code on the COPY
2. Assets: assets/ folder ki SAARI files upload (css, js, logo, bottle, ing-*.svg)
3. Sections: har .liquid file ke naam se naya section banayein aur code paste karein (perfume-scroll + 10 am-*.liquid)
4. Templates: templates/index.json ka code home page template mein paste karein (ya Customizer mein sections manually add karein)
5. Customizer: Products rails mein apni collection select karein. WhatsApp number AM Extras mein daalein. Discount code Shopify Admin > Discounts mein banayein (AMEZA15).
6. Announcement bar ko header ke upar chahiye to Customizer mein usay sabse upar rakhein.
Product cards ke liye inventory tracking on rakhein taake "Only X left" dikhe.

--- NAYA: Product page (PDP) ---
7. Naye sections: am-pdp-main, am-pdp-story, am-pdp-reviews, am-video (4 .liquid files) bhi isi tarah banayein
8. templates/product.json ka code Product template (Online Store > Themes > Edit code > Templates > product.json) mein paste karein
9. assets/drift-reel.webm bhi upload karein (default video). Apni video Customizer mein "AM Video" section mein upload/YouTube link se badal sakte hain
10. Home page par "AM Video" section Offer ke baad add ho gaya hai (index.json)
Reviews: asli reviews ke liye Judge.me / Loox app bhi use kar sakte hain, ye section manual reviews dikhata hai.

--- NAYA: Banner (video + text) ---
am-hero-split.liquid naya section banayein, assets/hero-arch-dark.webm aur hero-arch-light.webm upload karein, templates/index.json dobara paste karein. Customizer mein "AM Hero Video Split" ka Theme dark/light select hota hai.

--- Banner (animation left, text right) ---
Banner ab perfume-scroll.liquid hi hai (purani file ko naye code se replace karein) + templates/index.json dobara paste karein. am-hero-split ki zaroorat nahi.
